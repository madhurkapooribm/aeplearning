function createUserPw() {
    $.ajax({
    url: "https://parseapi.back4app.com/users",
    dataType: "json",
    type: "post",
    headers: {
        "X-Parse-Application-Id":"ynTCm6IxkWYrFsYKXtwjGnU1u9Loz2AqC0GY4Ty7",
        "X-Parse-REST-API-Key":"EUJB568FMxkE1OmvaJjrEcRYuRb9GGKOyfV0Cki2",
        "X-Parse-Revocable-Session":"1"
    },
    data: {
        "password": localStorage.getItem('password'),
        "username": localStorage.getItem('email'),
        "email": localStorage.getItem('email')
        }
    })
};