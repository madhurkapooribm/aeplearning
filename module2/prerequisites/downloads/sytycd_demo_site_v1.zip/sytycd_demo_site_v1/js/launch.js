var launchTagUrl = "//assets.adobedtm.com/85462031b1ac/44012061b67b/launch-753edcde4904-development.min.js";

dynamicallyLoadScript(launchTagUrl);

function dynamicallyLoadScript(url) {
    var script = document.createElement("script");
    script.src = url;
    script.async = true;
    document.head.appendChild(script);
}
